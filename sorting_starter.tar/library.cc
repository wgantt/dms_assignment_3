#include "library.h"

void mk_runs(FILE *in_fp, FILE *out_fp, long run_length, Schema *schema)
{
  // Your implementation
}

void merge_runs(RunIterator* iterators[], int num_runs, FILE *out_fp,
                long start_pos, char *buf, long buf_size)
{
  // Your implementation
}

